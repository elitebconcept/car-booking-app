const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const cors = require('cors');

const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

let bookings = [];
let drivers = [];
let users = [];
let trips = [];

// Simulate seat allocation
const seats = ['FRONT LEFT', 'BACK LEFT', 'BACK RIGHT'];

// Register user
app.post('/api/register', (req, res) => {
  const { name, email, idType, userType } = req.body;
  const user = { id: Date.now(), name, email, idType, userType };
  users.push(user);
  if (userType === 'driver') drivers.push({ ...user, online: false });
  res.json({ success: true, user });
});

// Driver Go Online
app.post('/api/driver/online', (req, res) => {
  const { driverId } = req.body;
  const onlineDriver = drivers.find(d => d.id === driverId);
  if (onlineDriver) {
    onlineDriver.online = true;
    res.json({ success: true });
  } else {
    res.status(404).json({ success: false });
  }
});

// Booking endpoint
app.post('/api/book', (req, res) => {
  const { userId, pickup, destination } = req.body;
  const seat = seats[bookings.length % 3];
  const booking = {
    id: Date.now(),
    userId,
    pickup,
    destination,
    seat,
    checkinCode: Math.random().toString(36).substring(2, 7).toUpperCase(),
  };
  bookings.push(booking);
  res.json({ success: true, booking });
});

// Admin view of trips
app.get('/api/admin/trips', (req, res) => {
  res.json({ trips, bookings, drivers });
});

// Serve frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
